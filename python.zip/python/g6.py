import cv2
import socket
import threading
from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from FaceRecognition import Face
import openpyxl
import matplotlib
from matplotlib.figure import Figure
def send(msg):
    socket_client.send(msg.encode())
def facelog():
    succ, name, idnum = Face()
    if succ == 1:
        Label(farme1, text=idnum, bg='white').place(x=200, y=50)
        Label(farme1, text=name, bg='white').place(x=200, y=100)
        Label(farme1,text ='登录成功',bg='white').place(x=150,y=200)
        send("B,1")
        global a33
        a = 'image.jpg'
        a1 = Image.open(a)
        a2 = a1.resize((90, 90))
        a33 = ImageTk.PhotoImage(a2)
        Label(farme1, image=a33).place(x=10, y=60)
    else:
        Label(farme1, text="                  ", bg='white').place(x=200, y=50)
        Label(farme1, text="                   ", bg='white').place(x=200, y=100)
        Label(farme1, text='登录失败', bg='white').place(x=150, y=200)
        send("B,2")
        global a333
        a = 'face.jpg'
        a1 = Image.open(a)
        a2 = a1.resize((90, 90))
        a333 = ImageTk.PhotoImage(a2)
        Label(farme1, image=a333).place(x=10, y=60)
def quxiao():
    Label(farme1, text="                  ", bg='white').place(x=200, y=50)
    Label(farme1, text="                   ", bg='white').place(x=200, y=100)
    Label(farme1, text='                     ', bg='white').place(x=150, y=200)
    global a3333
    a = 'face.jpg'
    a1 = Image.open(a)
    a2 = a1.resize((90, 90))
    a3333 = ImageTk.PhotoImage(a2)
    Label(farme1, image=a3333).place(x=10, y=60)
def draw(far,labels,colors):
    fig = Figure(figsize=(4,4),dpi=100)
    drawpic = fig.add_subplot(111)
    matplotlib.rcParams['font.sans-serif'] = ['SimHei']
    drawpic.pie(x=far,labels=labels,colors=colors,autopct="%.2ff%%")
    drawpic.set_title("扇形图")
    fig.savefig('pie.png')
def pie():
    global g3
    g = 'pie.png'
    g1 = Image.open(g)
    g2 = g1.resize((400,400))
    g3 = ImageTk.PhotoImage(g2)
    Label(farme3,image=g3).place(x=230,y=10)
def code():
    sum = 0
    low = 0
    mid = 0
    high = 0
    geli = 0
    while True:
        risk_list = []
        labels_list = []
        far = []
        colors = []

        command = socket_client.recv(1024).decode('utf-8')
        print(command)
        if 'sb' in command:

            img = cv2.imread("D:/VisionMaster/code.jpg")
            co = cv2.QRCodeDetector()
            a,b,c = co.detectAndDecode(img)
            dd = ''.join(a)
            send("C,"+dd)
            print(dd)
            d = dd.split(',')
            print(d)

            Label(farme2, text= d[0], bg='white').place(x=200, y=50)
            Label(farme2, text=d[1], bg='white').place(x=200, y=100)
            Label(farme2, text=d[2], bg='white').place(x=200, y=140)
            Label(farme2, text=d[3], bg='white').place(x=200, y=180)
            Label(farme2, text=d[4], bg='white').place(x=200, y=230)
            global b33
            b = 'D:/VisionMaster/code.jpg'
            b1 = Image.open(b)
            b2 = b1.resize((90, 90))
            b33 = ImageTk.PhotoImage(b2)
            Label(farme2, image=b33).place(x=10, y=60)

            sum +=1
            wendu = float(d[3])
            area = d[4]

            if wendu > 37.2:
                print("温度过高")
                geli +=1
                msg = "D,geli,{},{},{},{},{}".format(sum,low,mid,high,geli)
                send(msg)
            else:
                for k,v in risk.items():
                    if area in v:
                        print(k)
                        if k == "低风险":
                            low +=1
                            msg = "D,low,{},{},{},{},{}".format(sum, low, mid, high, geli)
                        elif k == "中风险":
                            mid +=1
                            msg = "D,mid,{},{},{},{},{}".format(sum, low, mid, high, geli)
                        elif k == "高风险":
                            high +=1
                            msg = "D,high,{},{},{},{},{}".format(sum, low, mid, high, geli)
                        elif k == "隔离区":
                            geli +=1
                            msg = "D,geli,{},{},{},{},{}".format(sum, low, mid, high, geli)
                        send(msg)
            Label(farme3, text=sum, bg='gray', width=15, height=3).place(x=100, y=10)
            Label(farme3, text=low, bg='green', width=15, height=3).place(x=100, y=90)
            Label(farme3, text=mid, bg='blue', width=15, height=3).place(x=100, y=180)
            Label(farme3, text=high, bg='yellow', width=15, height=3).place(x=100, y=270)
            Label(farme3, text=geli, bg='red', width=15, height=3).place(x=100, y=350)

            dic = {"低风险":[low,"green"],"中风险":[mid,"blue"],"高风险":[high,"yellow"],"隔离区":[geli,"red"]}
            for k in list(dic.keys()):
                if dic[k][0] == 0:
                    del dic[k]
                    continue
            for k,v in dic.items():
                risk_list.append(v)
                labels_list.append([k])
            labels = tuple(labels_list)

            for k in risk_list:
                far.append(k[0])
                colors.append(k[1])

            draw(far,labels,colors)
            pie()





            max_row = sheet1.max_row
            sheet1.cell(max_row+1,1).value = sum
            sheet1.cell(max_row+1,2).value = d[0]
            sheet1.cell(max_row+1,3).value = d[1]
            sheet1.cell(max_row+1,4).value = d[2]
            sheet1.cell(max_row+1,5).value = d[3]
            sheet1.cell(max_row+1,6).value = d[4]
            sheets.save("Data.xlsx")

            max_row1 = sheet1.max_row
            max_column1 = sheet1.max_column

            tree = ttk.Treeview(farme4)
            tree['column'] = ("序号", '姓名', '性别', '年龄', '体温', '行程')

            tree.column("序号", width=60)
            tree.column("姓名", width=60)
            tree.column("性别", width=60)
            tree.column("年龄", width=60)
            tree.column("体温", width=60)
            tree.column("行程", width=60)

            tree.heading("#1", text="序号")
            tree.heading("#2", text="姓名")
            tree.heading("#3", text="性别")
            tree.heading("#4", text="年龄")
            tree.heading("#5", text="体温")
            tree.heading("#6", text="行程")

            for i in range(2, max_row1 + 1):
                b = []
                for j in range(1, max_column1 + 1):
                    a = sheet1.cell(i, j).value
                    b.append(a)
                tree.insert('', index=END, text=i - 1, values=b)
            tree.place(x=10, y=20)
def back(a,b):
    a.place_forget()
    b.place(x=350, y=40)

def log():
    farme3.place_forget()
    farme4.place(x=350, y=40)

    # max_row1 = sheet1.max_row
    # max_column1 = sheet1.max_column

    # tree = ttk.Treeview(farme4)
    # tree['column'] = ("序号",'姓名','性别','年龄','体温','行程')
    #
    # tree.column("序号",width=60)
    # tree.column("姓名",width=60)
    # tree.column("性别",width=60)
    # tree.column("年龄",width=60)
    # tree.column("体温",width=60)
    # tree.column("行程",width=60)
    #
    # tree.heading("#1",text="序号")
    # tree.heading("#2",text="姓名")
    # tree.heading("#3",text="性别")
    # tree.heading("#4",text="年龄")
    # tree.heading("#5",text="体温")
    # tree.heading("#6",text="行程")

    # for i in range(2,max_row1+1):
    #     b = []
    #     for j in range(1,max_column1+1):
    #         a = sheet1.cell(i,j).value
    #         b.append(a)
    #     tree.insert('',index=END,text=i-1,values=b)
    tree.place(x=10,y=20)

    Button(farme4, text="返回扇形图界面",command=lambda:back(farme4,farme3)).place(x=100, y=500)
    Button(farme4, text="退出系统", command=quit).place(x=200, y=500)




if __name__ == '__main__':
    socket_client = socket.socket()
    socket_client.connect(('192.168.1.100',2001))

    risk= {"低风险": {"cityD", "cityH", "cityL", "cityP", "cityT", "cityX", "cityM", "cityQ", "cityU", "cityV", "cityY",
                   "cityZ"},
           "中风险": {"cityC", "cityG", "cityK", "cityO", "cityS", "cityW"},
           "高风险": {"cityB", "cityF", "cityJ", "cityN", "cityR"},
           "隔离区": {"cityA", "cityE", "cityI"},

           }

    workbook = openpyxl.Workbook()
    worksheet = workbook.active
    workbook.save("Data.xlsx")

    sheets = openpyxl.load_workbook("Data.xlsx")
    sheet1 = sheets[sheets.sheetnames[0]]
    sheet1.cell(1,1).value = "序号"
    sheet1.cell(1,2).value = "姓名"
    sheet1.cell(1,3).value = "性别"
    sheet1.cell(1,4).value = "年龄"
    sheet1.cell(1,5).value = "体温"
    sheet1.cell(1,6).value = "行程"
    sheets.save("Data.xlsx")
    win = Tk()
    win.geometry("1200x700")
    win.title("my")
    Label(win,text = '机场人员信息表').place(x=500,y=10)

    farme1 = Frame(win,width=300,height=300,bg='white')
    farme1.place(x=10,y=40)
    Label(farme1,text ='人脸登录框',bg='white').place(x=150,y=10)
    Label(farme1,text ='Face ID: ',bg='white').place(x=130,y=50)
    Label(farme1,text ='Name: ',bg='white').place(x=130,y=100)
    #Label(farme1,text ='登录成功',bg='white').place(x=150,y=200)
    Button(farme1,text="人脸登录",command=facelog).place(x=100,y=260)
    Button(farme1,text="注销",command=quxiao).place(x=200,y=260)
    a = 'face.jpg'
    a1 = Image.open(a)
    a2 = a1.resize((90,90))
    a3 = ImageTk.PhotoImage(a2)
    Label(farme1,image = a3).place(x=10,y=60)

    farme2 = Frame(win, width=300, height=300, bg='white')
    farme2.place(x=10, y=380)
    Label(farme2, text='人脸登录框', bg='white').place(x=150, y=10)
    Label(farme2, text='姓名：', bg='white').place(x=130, y=50)
    Label(farme2, text='性别：', bg='white').place(x=130, y=100)
    Label(farme2, text='年龄：', bg='white').place(x=130, y=140)
    Label(farme2, text='体温：', bg='white').place(x=130, y=180)
    Label(farme2, text='行程：', bg='white').place(x=130, y=230)
    Button(farme2, text="开始排查",command=lambda:send("A,wz")).place(x=100, y=260)
    Button(farme2, text="停止排查",command=lambda:send("A,tz")).place(x=200, y=260)
    b = 'code.jpg'
    b1 = Image.open(b)
    b2 = b1.resize((90, 90))
    b3 = ImageTk.PhotoImage(b2)
    Label(farme2, image=b3).place(x=10, y=60)

    farme3 = Frame(win, width=700, height=650, bg='white')
    farme3.place(x=350, y=40)
    Label(farme3, text='总人数：', bg='gray',width=15,height=3).place(x=10, y=10)
    Label(farme3, text='低风险人数：', bg='green',width=15,height=3).place(x=10, y=90)
    Label(farme3, text='中风险人数：', bg='blue',width=15,height=3).place(x=10, y=180)
    Label(farme3, text='高风险人数：', bg='yellow',width=15,height=3).place(x=10, y=270)
    Label(farme3, text='隔离区人数：', bg='red',width=15,height=3).place(x=10, y=350)
    Button(farme3,text = "数据监控界面",command=log).place(x=100,y=500)
    Button(farme3,text = "退出系统",command=quit).place(x=200,y=500)

    farme4 = Frame(win, width=700, height=650, bg='white')
    tree = ttk.Treeview(farme4)
    tree['column'] = ("序号", '姓名', '性别', '年龄', '体温', '行程')

    tree.column("序号", width=60)
    tree.column("姓名", width=60)
    tree.column("性别", width=60)
    tree.column("年龄", width=60)
    tree.column("体温", width=60)
    tree.column("行程", width=60)

    tree.heading("#1", text="序号")
    tree.heading("#2", text="姓名")
    tree.heading("#3", text="性别")
    tree.heading("#4", text="年龄")
    tree.heading("#5", text="体温")
    tree.heading("#6", text="行程")
    tree.place_forget()


    farme4.place_forget()

    th1 = threading.Thread(target=code)
    th1.daemon = True
    th1.start()

    win.mainloop()


















