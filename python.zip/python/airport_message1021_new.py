from tkinter import *
from tkinter import ttk
from FaceRecognition import Face
from PIL import Image, ImageTk 
import cv2#导入opencv库
import matplotlib
from matplotlib.figure import Figure
import socket
import threading
import openpyxl
import os
import time
# 人脸图片显示函数，所有的人脸图片显示的时候可以加载这个函数
def face_image(face_photo):
    global photo1  # 一定要将photo设置成全局变量不然调用显示不出来 image
    photo_open1 = Image.open('./' + face_photo + '.jpg') # 打开图片
    photo1 = photo_open1.resize((120 , 120))  # 图片尺寸
    photo1 = ImageTk.PhotoImage(photo1)   
    Label(Frame1,image=photo1).place(x= 50,y = 50) # 放置人脸图像的标签及位置

# 二维码图片显示函数，所有的二维码图片显示的时候可以加载这个函数
def code_image(code_photo):
    global photo2 # 一定要将photo设置成全局变量不然调用显示不出来 
    # 初始化的图片使用PIL库来加载图像
    photo_open2 = Image.open('./' + code_photo + '.jpg') # 打开图片
    photo2 = photo_open2.resize((100 , 100))  # 图片尺寸
    photo2 = ImageTk.PhotoImage(photo2)  # 放置二维码图像的标签及位置
    Label(Frame2,image=photo2).place(x= 50,y = 80) # 放置图像  

# 扇形图显示函数，所有的扇形图图片显示的时候可以加载这个函数
def pie_image():
    global photo3 # 一定要将photo设置成全局变量不然调用显示不出来 
    # 初始化的图片使用PIL库来加载图像  
    photo_open3 = Image.open('./pie.png') # 打开扇形图片
    photo3 = photo_open3.resize((400 , 400))  # 图片尺寸
    photo3 = ImageTk.PhotoImage(photo3)  # 放置二维码图像的标签及位置
    Label(Frame3,image=photo3).place(x= 240,y = 100) # 放置图像 

# 向TCP服务端返回数据
def senddata(text):
    socket_client.send(text.encode())

# 二维码接收函数
def code_loop():
    # 识别总人数sum
    sum = 0
    # 低风险人数
    low = 0
    # 中风险人数
    mid = 0
    # 高风险人数
    hight = 0
    # 隔离区人数
    quarantine = 0
    while(True):
        risk_list = []
        fraces = []  # 扇形图的占比初始值
        labels_list = []  # 扇形图的标签初始值
        colors = []
        command = socket_client.recv(1024).decode()  # 等待TCP服务端发送二维码信息
        print(command)
        if 'code' in command :  # 接收到code
            code_text = code_recognition()
            print(code_text)
            code_list  = code_recognition().split(',')  # 获取二维码中的数据
            Label(Frame2,text = code_list[0],font = ("微软雅黑",15), bg = "White" , width = 11 , height = 1 , anchor = 'w' ).place(x= 240,y = 45)  # 姓名
            Label(Frame2,text = code_list[1],font = ("微软雅黑",15), bg = "White" , width = 11 , height = 1, anchor = 'w' ).place(x= 240,y = 80)  # 性别
            Label(Frame2,text = code_list[2],font = ("微软雅黑",15), bg = "White" , width = 11 , height = 1, anchor = 'w' ).place(x= 240,y = 115)  # 年龄
            Label(Frame2,text = code_list[3],font = ("微软雅黑",15), bg = "White" , width = 11 , height = 1, anchor = 'w' ).place(x= 240,y = 150)  # 体温
            Label(Frame2,text = code_list[4],font = ("微软雅黑",15), bg = "White" , width = 11 , height = 1, anchor = 'w' ).place(x= 240,y = 185)  # 行程 
            senddata("C,"+code_text)
            time.sleep(1)
            code_image("code")  # 加载新的二维码图像到界面
            sum += 1  #识别人数+1
            temmometer=float(code_list[3])
            area = code_list[4]
            # 对二维码进行风险判断    
            if temmometer > 37.2:
                print("隔离区")
                quarantine += 1
                msg ="D,quarantine,{},{},{},{},{}".format(sum,low,mid,hight,quarantine)
                senddata(msg)     
            else :
                for k,v in risk.items(): 
                    if area in v:
                        print(k)
                        if k == "低风险": 
                            low += 1 
                            msg = "D,low,{},{},{},{},{}".format(sum,low,mid,hight,quarantine)
                        if k == "中风险": 
                            mid += 1 
                            msg = "D,mid,{},{},{},{},{}".format(sum,low,mid,hight,quarantine)
                        if k == "高风险": 
                            hight += 1
                            msg = "D,hight,{},{},{},{},{}".format(sum,low,mid,hight,quarantine)
                        if k == "隔离区": 
                            quarantine += 1
                            msg ="D,quarantine,{},{},{},{},{}".format(sum,low,mid,hight,quarantine)
                        senddata(msg)
            # 将风险区和对应值组合成字典，以下操作是为了剔除占比为0的那部分
            risk_dict = {"低风险" : [ low , "LawnGreen"], "中风险" : [mid , "DodgerBlue"] , "高风险" : [ hight , "Yellow" ] , "隔离区" : [ quarantine , "red"] }                        
            for k in list(risk_dict.keys()):  # 改为一个list（非迭代器）                     
                if risk_dict[k][0]== 0:  #提取列表索引为0的值
                    del risk_dict[k]  #删除键值为“0”的键和对应键值
                    continue        
                    
            # 将键值以列表形式拼接起来，作为扇形图的占fraces；同理键也以列表形式拼接起来为不同风险区labels_list                  
            for k,v in risk_dict.items():  # 遍历最终的字典
                risk_list.append(v)    # [[ low , "LawnGreen"],[mid , "DodgerBlue"]]  
                labels_list.append(k)  # ["低风险","中风险","高风险","隔离区"]    
            labels = tuple(labels_list)   # 转为元组,获取风险区对应标签  labels = ("低风险","中风险","高风险","隔离区")   
            
            #遍历嵌套列表 [[ low , "LawnGreen"],[mid , "DodgerBlue"]]
            for k in risk_list:                                       
                fraces.append(k[0])  # 获取风险区对应占比                 
                colors.append(k[1])    # 获取风险区对应颜色                      

            draw_pie(Frame3,labels,fraces,colors)  # 画扇形图
            pie_image()  # 将扇形图存显示在界面
            Label(Frame3,text = str(sum) + "个" , font = ("微软雅黑",12), bg = "Gray" , width = 5 , height = 2 , anchor = 'w').place(x= 200,y = 70)  
            Label(Frame3,text = str(low) + "个" , font = ("微软雅黑",12), bg = "LawnGreen" , width = 5 , height = 2 , anchor = 'w').place(x= 200,y = 170)  
            Label(Frame3,text = str(mid) + "个" , font = ("微软雅黑",12), bg = "DodgerBlue" , width = 5 , height = 2 , anchor = 'w').place(x= 200,y = 270)  
            Label(Frame3,text = str(hight) +"个" , font = ("微软雅黑",12), bg = "Yellow" , width = 5 , height = 2 , anchor = 'w').place(x= 200,y = 370) 
            Label(Frame3,text = str(quarantine) + "个" , font = ("微软雅黑",12), bg = "red" , width = 5 , height = 2 , anchor = 'w').place(x= 200,y = 470) 
            
            max_row1 = sheet1.max_row  # 获取该表格最大行行数 

            # 填写相关信息到表格
            sheet1.cell(max_row1+1,1).value = sum           # 填写到“序号”一栏
            sheet1.cell(max_row1+1,2).value = code_list[0]  # 填写到“姓名”一栏
            sheet1.cell(max_row1+1,3).value = code_list[1]  # 填写到“性别”一栏
            sheet1.cell(max_row1+1,4).value = code_list[2]  # 填写到“年龄”一栏
            sheet1.cell(max_row1+1,5).value = code_list[3]  # 填写到“体温”一栏
            sheet1.cell(max_row1+1,6).value = code_list[4]  # 填写到“行程”一栏
            sheets.save("Data.xlsx")  # 保存表格

# 人脸登录函数。function：face_login
def face_login():
    succ,name,face_id = Face() # 采集人脸数据
    if succ == 1:
        print(name,face_id )
        Label(Frame1,text = face_id , font = ("微软雅黑",15), fg = "LightSlateGray" , bg = "White").place(x= 280,y = 70)  # ID
        Label(Frame1,text = name , font = ("微软雅黑",15), fg = "LightSlateGray", bg = "White").place(x= 280,y = 120)  # 姓名  
        Label(Frame1,text = "登录成功！" , font = ("微软雅黑",14), fg = "lawngreen" , bg = "White").place(x= 150,y = 240) 
        face_image('image')  # 加载的是识别成功的人脸
        senddata("B,1")
    else:
        Label(Frame1,text = "登录失败 ！" , font = ("微软雅黑",14), fg = "red" , bg = "White").place(x= 150,y = 240)
        senddata("B,2")
# 注销函数。function：face_logout
def face_logout():
    Label(Frame1,text = "     " , font = ("微软雅黑",15), fg = "LightSlateGray" , bg = "White").place(x= 280,y = 70)  # 用空格顶掉原有的信息
    Label(Frame1,text = "      " , font = ("微软雅黑",15), fg = "LightSlateGray", bg = "White").place(x= 280,y = 120)  # 用空格顶掉原有的信息
    Label(Frame1,text = "                " , font = ("微软雅黑",20), fg = "lawngreen" , bg = "White").place(x= 150,y = 250) 
    face_image('face')  # 加载的是初始人脸logo
    senddata("B,0")
# 二维码识别，识别的是视觉拍摄的code.jpg    
def code_recognition():  
    img = cv2.imread("D:/VisionMaster/code.jpg")  # 打开二维码图片
    det = cv2.QRCodeDetector()  # 创建二维码识别器
    val, pts, st_code = det.detectAndDecode(img)#识别二维码
    # print(val)
    return val

# matplotlib模块画扇形图
def draw_pie(frame,labels,fraces , colors):
    # Figure创建图像对象，figsize指定画布的大小，(宽度,高度)，单位为英寸。
    # dpi 指定绘图对象的分辨率，即每英寸多少个像素，默认值为80
    fig = Figure(figsize=(4, 4), dpi=100)
    # subplot()均等划分画布,如果不想覆盖之前的图，需要使用 add_subplot() 函数
    drawPic_a = fig.add_subplot(111)
    # 解决汉字乱码问题，使用指定的汉字字体类型（此处为黑体）
    matplotlib.rcParams['font.sans-serif'] = ['SimHei']  
    # 颜色
    
    # 绘制pie()饼状图：labels为每个扇形区域备注一个标签名字,autopct格式化字符串"fmt%pct",百分比格式
    drawPic_a.pie(x=fraces, labels=labels, colors = colors , autopct='%0.2f%%') 
    drawPic_a.set_title('风险区分布图')  #饼状图命名
    fig.savefig('pie.png')  # 将扇形图保存到文件夹下






###farme444
#数据监控监控画面，使用Treeview来呈现表格内容
def data_monitor():
    print("数据监控")
    Frame3.pack_forget()  # 隐藏Frame3的组件，pack_forget()方法让控件“不再显示”但控件还存在可以再次pack出来
    Frame4 = Frame(top,bg="White",height=610,width=650)
    Frame4.place(x = 500 , y = 50)
    Button(Frame4,text = "返回统计图",bg = "gold",font = ("黑体",12),width = 18 , height = 2, command = Frame4.place_forget).place(x= 120,y = 550)   #返回统计按钮 
    Button(Frame4,text = "退出系统",bg = "Skyblue",font = ("黑体",12),width = 18 , height = 2, command = top.destroy).place(x= 450,y = 550)   #退出系统 
    
    max_row1 = sheet1.max_row  # 获取该表格最大行行数 
    max_column1 = sheet1.max_column  # 获取该表格最大列列数 
    # 表格。建立标题
    tree = ttk.Treeview(Frame4)       # 创建表格对象
    tree["columns"] = ("序号","姓名","性别","年龄","体温","行程")  # 定义列
    tree.column("序号" , width = 70 )  # 宽度
    tree.column("姓名" , width = 70 )
    tree.column("性别" , width = 70 )
    tree.column("年龄" , width = 70 )
    tree.column("体温" , width = 70 ) 
    tree.column("行程" , width = 70 ) 

    tree.heading("#0" , text = "序号")  # 表格标题
    tree.heading("#1" , text = "姓名")
    tree.heading("#2" , text = "性别")
    tree.heading("#3" , text = "年龄")
    tree.heading("#4" , text = "体温")
    tree.heading("#5" , text = "行程")
    for i in range(2,max_row1+1):  # 从表格第2行开始遍历
        b = []  # 设空列表
        for j in range(1,max_column1+1):  # 遍历每一列，获取每一行的列内容
            a = sheet1.cell(i,j).value   # 获取每一个单元格的值，
            b.append(a)  # 字符串转列表，例如第2行：[1，小红，女，18，深圳南山]
            
        del(b[0])   # 删除第一个序号
        tree.insert("", index = END , text = i-1,values=b)  # 加载到表格上，text是序号，values是序号后的内容（人员信息内容）
    tree.place(x=20,y=50)





if __name__ == '__main__':
        
    # 创建socket客户端变量
    socket_client = ''
    # 创建全局变量
    global command
    socket_client = socket.socket()
    socket_client.connect(('192.168.1.20', 2001))

    #颜色
    mycolor='#%02x%02x%02x'%(00,32,96)
    
  
    # 风险区划分（具体划分还需要详细说明）：低风险除了中、隔离的都是低，低风险可去掉
    risk = {"低风险":{"cityD","cityH","cityL","cityP","cityT","cityX","cityM","cityQ","cityU","cityV","cityY","cityZ"}, 
            "中风险":{"cityC","cityG","cityK","cityO","cityS","cityW"},
            "高风险":{"cityB","cityF","cityJ","cityN","cityR"},
            "隔离区":{"cityA","cityE","cityI"}}

    # 创建一个新表格，用于存储人员信息，每次打开都覆盖原来的表格
    workbook = openpyxl.Workbook()  # 创建一个工作薄
    worksheet = workbook.active  # 在工作薄中创建一个工作表
    workbook.save("Data.xlsx")  # 保存表格到对应路径  
    # 打开工作表
    sheets = openpyxl.load_workbook("Data.xlsx")  

    # 在表格第一行填写内容
    sheet1 = sheets[sheets.sheetnames[0]]   
    sheet1.cell(1, 1).value = "序号"
    sheet1.cell(1, 2).value = "姓名"
    sheet1.cell(1, 3).value = "性别"  
    sheet1.cell(1, 4).value = "年龄" 
    sheet1.cell(1, 5).value = "体温"  
    sheet1.cell(1, 6).value = "行程"  
    sheets.save("Data.xlsx")  # 保存表格

    # 主界面程序
    top = Tk()
    top.title("金砖大赛")  # 窗口标题
    top.geometry("1200x700")  # 窗口尺寸
    top.configure(bg = mycolor)  # 窗口背景颜色
    # 大标题"机场人员流调系统"
    Label(top ,text = "机场人员流调系统",font = ("宋体",18),fg = "White",bg = "Navy",width = 30,height = 2).place(x=420,y = 0)

    # 设置3个Frame框架组件，用来存放人脸识别、人员信息、风险布局
    # 第一个框架：人脸登录、注销
    Frame1 = Frame(top,bg="White",height=280,width=400)
    Frame1.place(x = 50 , y = 50)
    Label(Frame1,text = "人脸识别",font = ("微软雅黑",15), bg = "White" , width = 10 , height = 1).place(x= 130,y = 10)  # 姓名
    Button(Frame1,text = "人脸登录",bg = "LightSeaGreen",font = ("黑体",12),width = 10,height = 2,command = face_login).place(x = 80 , y = 180)  #人脸登出按钮
    Button(Frame1,text = "注销",bg = "Gold",font = ("黑体",12),width = 10 , height = 2,command = face_logout).place(x= 230,y = 180)   #注销按钮
    # 第一个框架：人脸登录、注销
    face_image('face')  # 初始化人脸图像
    Label(Frame1,text = "Face ID:",font = ("微软雅黑",15), bg = "White" , width = 10 , height = 1).place(x= 150,y = 70)  # ID
    Label(Frame1,text = "  Name:",font = ("微软雅黑",15), bg = "White" , width = 10 , height = 1).place(x= 150,y = 120)  # 姓名

    # 第二个框架：人员信息识别
    Frame2 = Frame(top,bg="White",height=280,width=400)
    Frame2.place(x = 50 , y = 380)
    Label(Frame2,text = "人员信息识别",font = ("微软雅黑",15), bg = "White" , width = 10 , height = 1).place(x= 130,y = 10)  
    # 第二个框架：人员信息识别
    code_image("code0")  # 初始化二维码图像
    Label(Frame2,text = "姓名: " , font = ("微软雅黑",15), bg = "White" , width = 8 , height = 1 , anchor = 'w' ).place(x= 170,y = 45)  # 姓名
    Label(Frame2,text = "性别: " , font = ("微软雅黑",15), bg = "White" , width = 8 , height = 1, anchor = 'w' ).place(x= 170,y = 80)  # 性别
    Label(Frame2,text = "年龄: " , font = ("微软雅黑",15), bg = "White" , width = 8 , height = 1, anchor = 'w' ).place(x= 170,y = 115)  # 年龄
    Label(Frame2,text = "体温: " , font = ("微软雅黑",15), bg = "White" , width = 8 , height = 1, anchor = 'w' ).place(x= 170,y = 150)  # 体温 
    Label(Frame2,text = "行程: " , font = ("微软雅黑",15), bg = "White" , width = 8 , height = 1, anchor = 'w' ).place(x= 170,y = 185)  # 行程
    Button(Frame2,text = "开始排查",bg = "Green",font = ("黑体",11),width = 10,height = 2,command = lambda : senddata("A,start")).place(x = 80 , y = 230)  #发送数据
    Button(Frame2,text = "停止排查",bg = "red",font = ("黑体",11),width = 10 , height = 2, command = lambda : senddata("A,stop")).place(x= 230,y = 230)   #发送数据

    # 第三个框架：人员信息识别 
    Frame3 = Frame(top,bg="White",height=610,width=650)
    Frame3.place(x = 500 , y = 50)
    Label(Frame3,text = "识别总人数: ", font = ("微软雅黑",12), bg = "Gray" , width = 15 , height = 2 ).place(x= 50,y = 70)  
    Label(Frame3,text = "低风险人数: " , font = ("微软雅黑",12), bg = "LawnGreen" , width = 15 , height = 2 ).place(x= 50,y = 170)  
    Label(Frame3,text = "中风险人数: " , font = ("微软雅黑",12), bg = "DodgerBlue" , width = 15 , height = 2 ).place(x= 50,y = 270)  
    Label(Frame3,text = "高风险人数: " , font = ("微软雅黑",12), bg = "Yellow" , width = 15 , height = 2 ).place(x= 50,y = 370) 
    Label(Frame3,text = "隔离区人数: " , font = ("微软雅黑",12), bg = "red" , width = 15 , height = 2 ).place(x= 50,y = 470) 
    Button(Frame3,text = "数据监控画面",bg = "Skyblue",font = ("黑体",12),width = 18 , height = 2, command = data_monitor).place(x= 120,y = 550)   #数据监控画面按钮 
    Button(Frame3,text = "退出系统",bg = "Skyblue",font = ("黑体",12),width = 18 , height = 2, command = top.destroy).place(x= 450,y = 550)   #退出系统    
    # 开启线程，用于接收识别二维码，更新到界面
    thread = threading.Thread(target=code_loop)
    thread.daemon = True
    thread.start()
    
    top.mainloop()  # 消息循环

