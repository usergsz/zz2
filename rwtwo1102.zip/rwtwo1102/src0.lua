-- Version: Lua 5.3.5
-- 此线程为主线程，可调用任何指令

local ip="192.168.1.100"
local port=2004
local err=0
local socket=0


while true do
	::create_server::
	err, socket = TCPCreate(false, ip, port)
	if err ~= 0 then
		print("Failed to create socket, re-connecting")
		Sleep(1000)
		goto create_server
	end
	err = TCPStart(socket, 0)
	if err ~= 0 then
		print("Failed to start server, re-connecting")
		TCPDestroy(socket)
		Sleep(1000)
		goto create_server
	end
	while true do
		err, buf = TCPRead(socket, 0,"string")
		data =buf.buf
		print("\r".."接收的内容"..data.."\r")
		if err ~= 0 then
			print("Failed to read data, re-connecting")
			TCPDestroy(socket)
			Sleep(1000)
			break
		end
		if  data== "low" then
			Jump(P2,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,1)
			Jump(P3,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,0)
			Jump(P1,"Start=220,ZLimit=220,End=220,SYNC=1")
			TCPWrite(socket,"wzfw")
		elseif data == "mid" then
			Jump(P2,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,1)
			Jump(P4,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,0)
			Jump(P1,"Start=220,ZLimit=220,End=220,SYNC=1")
			TCPWrite(socket,"wzfw")
		elseif data == "high" then
			Jump(P2,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,1)
			Jump(P5,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,0)
			Jump(P1,"Start=220,ZLimit=220,End=220,SYNC=1")
			TCPWrite(socket,"wzfw")
		elseif data == "geli" then
			Jump(P2,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,1)
			Jump(P6,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,0)
			Jump(P1,"Start=220,ZLimit=220,End=220,SYNC=1")
			TCPWrite(socket,"wzfw")
		end

	end
end